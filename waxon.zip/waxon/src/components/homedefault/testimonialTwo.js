import React from 'react';

const TestimonialTwo = () => {
    return (
        <div>
            
        </div>
    )
}

export default TestimonialTwo;
